
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
public class UserDb 
{
    String s1=null;
    public String insertUser(RegisterBean rb)
    {
        MYDb db= new MYDb();
        Connection con=db.getCon();
        try
        {
            Statement stmt=con.createStatement();
            stmt.executeUpdate("insert into ABC.REGISTER (NAME,EMAIL,PASSWORD) values ('"+rb.getName()+"','"+rb.getEmail()+"','"+rb.getPassword()+"')");
            s1="Data inserted";
        }
        catch(SQLException e)
        {
            System.out.println(e);
        }
        return s1;
    }
}
