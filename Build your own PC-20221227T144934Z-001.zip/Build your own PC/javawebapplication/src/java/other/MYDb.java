
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MYDb 
{
    Connection con=null;
    public Connection getCon()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:derby://localhost:1527/pc","abc","abc");
        }
        
        catch(ClassNotFoundException e)
        {
            System.out.println(e);
        }
        catch(SQLException e)
        {
            System.out.println(e);
        }
        return con;
    }
}
